<?php

// php populate html table from mysql database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "master";

// connect to mysql
$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysql select query

$query = "SELECT * FROM `data";


// result for method one
$result1 = mysqli_query($connect, $query);

// result for method two
$result2 = mysqli_query($connect, $query);

$dataRow = "";

while($row2 = mysqli_fetch_array($result2))
{
    $dataRow = $dataRow."<tr><td>$row2[0]</td><td>$row2[1]</td><td>$row2[2]</td><td>$row2[3]</td></tr>";
}

?>

<!DOCTYPE html>

<html>

    <head>

        <title>PHP DATA ROW TABLE FROM DATABASE</title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" type="text/css" href="style.css">
        

        
    </head>

    <body>

<!-- Table One -->
        <table class="input-group">

            <tr>
                <th>Name</th>
                <th>Address line1</th>
                <th>Address line2</th>
                <th>email</th>
            </tr>

            <?php while($row1 = mysqli_fetch_array($result1)):;?>
            <tr>
                <td><?php echo $row1[0];?></td>
                <td><?php echo $row1[1];?></td>
                <td><?php echo $row1[2];?></td>
                <td><?php echo $row1[3];?></td>
            </tr>
            <?php endwhile;?>

        </table>

        <br><br>


 <!-- Table Two -->
        <table class="input-group">
            <tr>
                <th>Name</th>
                <th>Address line1</th>
                <th>Address line2</th>
                <th>email</th>
            </tr>

            <?php echo $dataRow;?>

        </table>

    </body>

</html>
